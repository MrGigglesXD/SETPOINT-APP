import { Volleyball, Hourglass, BarChart3, History } from "lucide-react";

function ComingSoon({
  icon: Icon,
  title,
  description,
}: {
  icon: React.ElementType;
  title: string;
  description: string;
}) {
  return (
    <div className="flex flex-col items-center justify-center text-center gap-3 p-10 h-full">
      <Icon size={48} className="text-muted" />
      <div className="text-lg font-bold">{title}</div>
      <div className="text-sm text-muted max-w-xs">{description}</div>
    </div>
  );
}

export function MatchPage() {
  return (
    <ComingSoon
      icon={Volleyball}
      title="Generador de Partidos"
      description="Próximamente: genera equipos balanceados 6v6 y administra el partido en vivo."
    />
  );
}

export function QueuePage() {
  return (
    <ComingSoon
      icon={Hourglass}
      title="Cola de Espera"
      description="Próximamente: visualiza la cola de jugadores esperando turno."
    />
  );
}

export function StatsPage() {
  return (
    <ComingSoon
      icon={BarChart3}
      title="Estadísticas"
      description="Próximamente: ranking, win rate y participación de jugadores."
    />
  );
}

export function HistoryPage() {
  return (
    <ComingSoon
      icon={History}
      title="Historial"
      description="Próximamente: historial completo de partidos jugados."
    />
  );
}
