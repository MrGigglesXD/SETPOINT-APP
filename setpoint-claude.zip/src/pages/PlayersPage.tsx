import { useEffect, useState } from "react";
import { Plus, Search, Pencil, Trash2, X, Check, MapPin } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, Pill, Avatar } from "@/components/ui/card";
import { Input, Select, Textarea } from "@/components/ui/input";
import { Modal } from "@/components/ui/modal";
import { showToast } from "@/components/ui/toast";
import {
  usePlayersStore,
  selectFilteredPlayers,
} from "@/stores/usePlayersStore";
import {
  hasArrived,
  levelStars,
  initials,
  waitMinutes,
  type Player,
} from "@/types/player";
import { parseImportText } from "@/lib/playersApi";

export function PlayersPage() {
  const {
    players,
    loading,
    error,
    searchQuery,
    loadPlayers,
    addPlayer,
    editPlayer,
    removePlayer,
    markArrived,
    unmarkArrived,
    importPlayers,
    setSearchQuery,
    clearError,
  } = usePlayersStore();

  const filtered = selectFilteredPlayers(usePlayersStore.getState());

  const [showAddForm, setShowAddForm] = useState(false);
  const [showImport, setShowImport] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Player | null>(null);

  // add form fields
  const [newName, setNewName] = useState("");
  const [newLevel, setNewLevel] = useState(3);
  const [newArrived, setNewArrived] = useState(true);

  // import field
  const [importText, setImportText] = useState("");

  // edit fields
  const [editName, setEditName] = useState("");
  const [editLevel, setEditLevel] = useState(3);

  useEffect(() => {
    loadPlayers();
  }, []);

  useEffect(() => {
    if (error) {
      showToast(error);
      clearError();
    }
  }, [error]);

  async function handleAdd() {
    if (!newName.trim()) {
      showToast("Escribe un nombre");
      return;
    }
    try {
      await addPlayer({ name: newName.trim(), level: newLevel, mark_arrived: newArrived });
      showToast(`✓ ${newName.trim()} agregado${newArrived ? " y marcado como llegado" : ""}`);
      setNewName("");
      setNewLevel(3);
      setNewArrived(true);
      setShowAddForm(false);
    } catch {
      // error toast handled by effect
    }
  }

  async function handleImport() {
    if (!importText.trim()) {
      showToast("Pega una lista primero");
      return;
    }
    const rows = parseImportText(importText);
    if (!rows.length) {
      showToast("No se encontraron jugadores válidos");
      return;
    }
    try {
      const result = await importPlayers(rows);
      showToast(
        `✓ ${result.added} agregados${result.skipped ? `, ${result.skipped} omitidos (duplicados)` : ""}`
      );
      setImportText("");
      setShowImport(false);
    } catch {
      // handled by effect
    }
  }

  function startEdit(p: Player) {
    setEditingId(p.id);
    setEditName(p.name);
    setEditLevel(p.level);
  }

  async function handleSaveEdit() {
    if (!editingId) return;
    if (!editName.trim()) {
      showToast("El nombre no puede estar vacío");
      return;
    }
    try {
      await editPlayer({ id: editingId, name: editName.trim(), level: editLevel });
      showToast("✓ Jugador actualizado");
      setEditingId(null);
    } catch {
      // handled by effect
    }
  }

  async function handleDelete() {
    if (!deleteTarget) return;
    try {
      await removePlayer(deleteTarget.id);
      showToast("Jugador eliminado");
      setDeleteTarget(null);
    } catch {
      // handled by effect
    }
  }

  async function toggleArrival(p: Player) {
    try {
      if (hasArrived(p)) {
        await unmarkArrived(p.id);
      } else {
        await markArrived(p.id);
        showToast(`✓ ${p.name} marcado como llegado`);
      }
    } catch {
      // handled by effect
    }
  }

  return (
    <div className="flex flex-col gap-3.5 p-4">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-extrabold">
          🏐 SET<span className="text-setpoint-yellow">POINT</span>
        </h1>
        <span className="text-xs text-muted font-semibold">
          {players.length} jugador{players.length === 1 ? "" : "es"}
        </span>
      </div>

      {/* Action buttons */}
      <div className="grid grid-cols-2 gap-2">
        <Button variant="yellow" onClick={() => setShowAddForm((v) => !v)}>
          <Plus size={18} /> Agregar
        </Button>
        <Button variant="ghost" onClick={() => setShowImport((v) => !v)}>
          📋 Importar
        </Button>
      </div>

      {/* Add player form */}
      {showAddForm && (
        <Card className="flex flex-col gap-2.5">
          <div className="text-sm font-bold">Nuevo jugador</div>
          <Input
            placeholder="Nombre"
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            maxLength={24}
            autoFocus
          />
          <div className="grid grid-cols-2 gap-2">
            <Select value={newLevel} onChange={(e) => setNewLevel(Number(e.target.value))}>
              {[1, 2, 3, 4, 5].map((l) => (
                <option key={l} value={l}>
                  Nivel {l}
                </option>
              ))}
            </Select>
            <Select
              value={newArrived ? "yes" : "no"}
              onChange={(e) => setNewArrived(e.target.value === "yes")}
            >
              <option value="yes">Marcar llegada</option>
              <option value="no">Solo registrar</option>
            </Select>
          </div>
          <Button variant="yellow" fullWidth onClick={handleAdd}>
            + Agregar Jugador
          </Button>
          <Button variant="ghost" size="sm" onClick={() => setShowAddForm(false)}>
            Cancelar
          </Button>
        </Card>
      )}

      {/* Import form */}
      {showImport && (
        <Card className="flex flex-col gap-2.5">
          <div className="text-sm font-bold">Importar jugadores</div>
          <div className="text-xs text-muted">
            Formato: una línea por jugador, "Nombre Nivel" (nivel opcional, 1-5).
          </div>
          <Textarea
            rows={4}
            placeholder={"Andres 4\nAna 2\nMiguel 5\nCarlos 3"}
            value={importText}
            onChange={(e) => setImportText(e.target.value)}
          />
          <Button variant="yellow" fullWidth onClick={handleImport}>
            📋 Importar lista
          </Button>
          <Button variant="ghost" size="sm" onClick={() => setShowImport(false)}>
            Cancelar
          </Button>
        </Card>
      )}

      {/* Search */}
      <div className="relative">
        <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted" />
        <Input
          placeholder="Buscar jugadores…"
          className="pl-9"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
      </div>

      {/* Player list */}
      {loading && players.length === 0 ? (
        <div className="text-center py-8 text-muted text-sm">Cargando…</div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-8 text-muted text-sm">
          {players.length ? "Sin resultados" : "No hay jugadores aún. Agrega el primero arriba."}
        </div>
      ) : (
        <div className="flex flex-col gap-2">
          {filtered.map((p) => (
            <PlayerCard
              key={p.id}
              player={p}
              editing={editingId === p.id}
              editName={editName}
              editLevel={editLevel}
              onEditNameChange={setEditName}
              onEditLevelChange={setEditLevel}
              onStartEdit={() => startEdit(p)}
              onCancelEdit={() => setEditingId(null)}
              onSaveEdit={handleSaveEdit}
              onDelete={() => setDeleteTarget(p)}
              onToggleArrival={() => toggleArrival(p)}
            />
          ))}
        </div>
      )}

      {/* Delete confirmation */}
      <Modal
        open={!!deleteTarget}
        title={`¿Eliminar a ${deleteTarget?.name}?`}
        description="Esta acción no se puede deshacer."
        onClose={() => setDeleteTarget(null)}
        actions={[{ label: "Eliminar", onClick: handleDelete, variant: "red" }]}
      />
    </div>
  );
}

function PlayerCard({
  player: p,
  editing,
  editName,
  editLevel,
  onEditNameChange,
  onEditLevelChange,
  onStartEdit,
  onCancelEdit,
  onSaveEdit,
  onDelete,
  onToggleArrival,
}: {
  player: Player;
  editing: boolean;
  editName: string;
  editLevel: number;
  onEditNameChange: (v: string) => void;
  onEditLevelChange: (v: number) => void;
  onStartEdit: () => void;
  onCancelEdit: () => void;
  onSaveEdit: () => void;
  onDelete: () => void;
  onToggleArrival: () => void;
}) {
  const arrived = hasArrived(p);
  const statusPill = () => {
    if (p.status === "blue") return <Pill variant="blue">En partido (Azul)</Pill>;
    if (p.status === "red") return <Pill variant="red">En partido (Rojo)</Pill>;
    if (p.status === "waiting")
      return <Pill variant="gray">En espera · {waitMinutes(p.arrival_time)}m</Pill>;
    return null;
  };

  return (
    <Card className="flex flex-col gap-2">
      <div className="flex items-center gap-2.5">
        <Avatar initials={initials(p.name)} className="h-9 w-9" />
        <div className="flex-1 min-w-0">
          <div className="text-[15px] font-bold leading-tight">{p.name}</div>
          <div className="text-[11px] text-muted mt-0.5 flex items-center gap-1.5 flex-wrap">
            <span className="text-setpoint-yellow tracking-tighter">{levelStars(p.level)}</span>
            <span>· ELO {p.elo}</span>
            {statusPill()}
          </div>
        </div>
        <button
          onClick={onToggleArrival}
          className={`p-2 rounded-lg transition-colors ${
            arrived
              ? "bg-setpoint-green/15 text-setpoint-green"
              : "bg-card3 text-muted"
          }`}
          title={arrived ? "Marcado como llegado" : "Marcar llegada"}
        >
          <MapPin size={16} />
        </button>
      </div>

      <div className="flex items-center gap-3 text-[11px] text-muted">
        <span>🏐 {p.matches_played} partidos</span>
        <span className="text-setpoint-green">✓ {p.wins}</span>
        <span className="text-setpoint-red-text">✕ {p.losses}</span>
        {p.matches_played > 0 && (
          <span>
            · {Math.round((p.wins / p.matches_played) * 100)}% victorias
          </span>
        )}
      </div>

      {editing ? (
        <div className="flex flex-col gap-2 bg-card2 rounded-xl p-2.5 mt-1">
          <Input
            value={editName}
            onChange={(e) => onEditNameChange(e.target.value)}
            maxLength={24}
            autoFocus
          />
          <Select value={editLevel} onChange={(e) => onEditLevelChange(Number(e.target.value))}>
            {[1, 2, 3, 4, 5].map((l) => (
              <option key={l} value={l}>
                Nivel {l}
              </option>
            ))}
          </Select>
          <div className="grid grid-cols-2 gap-2">
            <Button variant="ghost" size="sm" onClick={onCancelEdit}>
              <X size={14} /> Cancelar
            </Button>
            <Button variant="yellow" size="sm" onClick={onSaveEdit}>
              <Check size={14} /> Guardar
            </Button>
          </div>
        </div>
      ) : (
        <div className="flex gap-2">
          <Button variant="ghost" size="sm" className="flex-1" onClick={onStartEdit}>
            <Pencil size={13} /> Editar
          </Button>
          <Button variant="danger" size="sm" className="flex-1" onClick={onDelete}>
            <Trash2 size={13} /> Eliminar
          </Button>
        </div>
      )}
    </Card>
  );
}
