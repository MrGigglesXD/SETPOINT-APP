import { Users, Volleyball, Hourglass, BarChart3, History } from "lucide-react";
import { cn } from "@/lib/utils";

export type Tab = "players" | "match" | "queue" | "stats" | "history";

const tabs: { id: Tab; label: string; icon: React.ElementType }[] = [
  { id: "players", label: "Jugadores", icon: Users },
  { id: "match", label: "Partido", icon: Volleyball },
  { id: "queue", label: "Cola", icon: Hourglass },
  { id: "stats", label: "Stats", icon: BarChart3 },
  { id: "history", label: "Historial", icon: History },
];

export function BottomNav({
  active,
  onChange,
}: {
  active: Tab;
  onChange: (tab: Tab) => void;
}) {
  return (
    <div className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-[480px] bg-card border-t border-border2 flex z-50 pb-[env(safe-area-inset-bottom)]">
      {tabs.map(({ id, label, icon: Icon }) => (
        <button
          key={id}
          onClick={() => onChange(id)}
          className={cn(
            "flex-1 flex flex-col items-center gap-1 py-2.5 min-h-[56px] text-muted transition-colors",
            active === id && "text-setpoint-yellow"
          )}
        >
          <Icon size={22} strokeWidth={2.2} />
          <span className="text-[10px] font-bold">{label}</span>
        </button>
      ))}
    </div>
  );
}
