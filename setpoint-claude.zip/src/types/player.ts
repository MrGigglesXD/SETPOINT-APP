// ════════════════════════════════════════════════════════
// Player types - mirror src-tauri/src/models.rs
// ════════════════════════════════════════════════════════

export type PlayerStatus = "available" | "blue" | "red" | "waiting" | "absent";

export interface Player {
  id: string;
  name: string;
  level: number; // 1-5
  elo: number;
  /** ISO 8601 string, empty string "" if never arrived */
  arrival_time: string;
  matches_played: number;
  wins: number;
  losses: number;
  status: PlayerStatus;
  created_at: string;
  updated_at: string;
}

export interface NewPlayer {
  name: string;
  level: number;
  mark_arrived: boolean;
}

export interface UpdatePlayer {
  id: string;
  name: string;
  level: number;
}

export interface ImportPlayerRow {
  name: string;
  level: number;
}

export interface ImportResult {
  added: number;
  skipped: number;
  skipped_names: string[];
}

// ════════════════════════════════════════════════════════
// Derived / computed helpers used across the UI
// ════════════════════════════════════════════════════════

export function hasArrived(p: Player): boolean {
  return !!p.arrival_time && p.arrival_time.length > 0;
}

export function eloToStars(elo: number): string {
  if (elo >= 1550) return "★★★★★";
  if (elo >= 1400) return "★★★★";
  if (elo >= 1250) return "★★★";
  if (elo >= 1100) return "★★";
  return "★";
}

export function levelStars(level: number): string {
  return "★★★★★".slice(0, level) + "☆☆☆☆☆".slice(0, 5 - level);
}

export function initials(name: string): string {
  return (
    name
      .trim()
      .split(/\s+/)
      .map((w) => w[0] || "")
      .join("")
      .toUpperCase()
      .slice(0, 2) || "??"
  );
}

export function waitMinutes(arrivalTime: string): number {
  if (!arrivalTime) return 0;
  const arrived = new Date(arrivalTime).getTime();
  return Math.max(0, Math.floor((Date.now() - arrived) / 60000));
}
