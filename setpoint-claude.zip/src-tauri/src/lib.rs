mod db;
mod error;
mod models;
mod players;

use players::DbState;
use tauri::Manager;

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    tauri::Builder::default()
        .plugin(tauri_plugin_fs::init())
        .plugin(tauri_plugin_dialog::init())
        .setup(|app| {
            let app_handle = app.handle().clone();

            // Resolve app data dir (platform-appropriate: ~/Library/Application Support/... on macOS,
            // app sandbox container on iOS).
            let app_data_dir = app_handle
                .path()
                .app_data_dir()
                .expect("failed to resolve app data dir");

            tauri::async_runtime::block_on(async move {
                let db_path = db::resolve_db_path(&app_data_dir)
                    .expect("failed to resolve db path");

                let pool = db::init_pool(&db_path)
                    .await
                    .expect("failed to initialize database");

                app_handle.manage(DbState(pool));
            });

            Ok(())
        })
        .invoke_handler(tauri::generate_handler![
            players::get_players,
            players::get_player,
            players::search_players,
            players::create_player,
            players::update_player,
            players::delete_player,
            players::set_player_status,
            players::mark_arrived,
            players::unmark_arrived,
            players::import_players,
        ])
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}
